local sw,sh =guiGetScreenSize()

infoTable = {}
Login_Edit = {}
NGCButtons = {}



LoginTab = {
    checkbox = {},
    staticimage = {},
    edit = {},
    label = {}
}

registerTab = {
    label = {},
    staticimage = {}
}


requestTab = {
    label = {},
    staticimage = {}
	}

updatesTab = {
    gridlist = {},
    staticimage = {},
    label = {},
    memo = {}
	}

-- Get the username and/or password is saved
function getAccountXMLData ()
	local theFile = xmlLoadFile ( "@account.xml" )
	if not ( theFile ) then
		theFile = xmlCreateFile( "@account.xml","accounts" )
		xmlCreateChild( theFile, "username" )
		xmlCreateChild( theFile, "password" )
		xmlSaveFile( theFile )
		return "", ""
	else
		usernameNode = xmlFindChild( theFile, "username", 0 )
		username = xmlNodeGetValue ( usernameNode )
		passwordNode = xmlFindChild( theFile, "password", 0 )
		password = xmlNodeGetValue ( passwordNode )
		return username, password
	end
	xmlUnloadFile(theFile)
end

-- Update the XML file with the new data
addEvent ( "updateAccountXMLData", true )
addEventHandler( "updateAccountXMLData", root,
	function ( username, password, usernameTick )
		local theFile = xmlLoadFile ( "@account.xml" )
		if not ( theFile ) then
			theFile = xmlCreateFile( "@account.xml","accounts" )
			xmlCreateChild( theFile, "username" )
			xmlCreateChild( theFile, "password" )
			xmlSaveFile( theFile )
		else
			usernameNode = xmlFindChild( theFile, "username", 0 )
			xmlNodeSetValue( usernameNode, username )
			passwordNode = xmlFindChild( theFile, "password", 0 )
			xmlNodeSetValue( passwordNode, password )
			if not ( usernameTick ) then
				usernameNode = xmlFindChild( theFile, "username", 0 )
				xmlNodeSetValue( usernameNode, "" )
				passwordNode = xmlFindChild( theFile, "password", 0 )
				xmlNodeSetValue( passwordNode, "" )
			end
			xmlSaveFile( theFile )
			xmlUnloadFile(theFile)
		end
	end
)

--Button
--[[function createButton(x,y,widht,height,text,bool,parent,info)
	button = guiCreateStaticImage(x,y,widht,height,"images/button_standart.png", bool,parent or nil)
	table.insert(NGCButtons,button)
	guiBringToFront(button)
	label = guiCreateLabel(0,0,1,0.8,text,true,button)
	guiLabelSetColor(label, 250, 255, 255)
	guiBringToFront(label)
	setElementData(label,"parent",button)
	setElementData(button,"info",info)
	setElementData(button,"whereLabel",label)
	guiSetFont(label,"default-bold-small")
	guiLabelSetVerticalAlign (label, "center")
	guiLabelSetHorizontalAlign (label, "center")
	addEventHandler("onClientMouseEnter",label,markButton,false)
	addEventHandler("onClientMouseLeave",label,unmarkButton,false)
	return label
end]]--

function markButton ()
parent = getElementData(source,"parent")
guiStaticImageLoadImage (parent,"images/button_mouse.png")
setElementData(getLocalPlayer(),"clickedButton",parent)
end

function unmarkButton (b,s)
parent = getElementData(source,"parent")
guiStaticImageLoadImage (parent,"images/button_standart.png")
setElementData(getLocalPlayer(),"clickedButton",false)
end
--Button end
local rx, ry = guiGetScreenSize()
function createAccountingWindows()

    local username, password = getAccountXMLData ()

	LoginTab.staticimage[1] = guiCreateStaticImage(0, 0, rx,ry, "images/main.jpg", false)
	guiSetProperty ( LoginTab.staticimage[1], "AlwaysOnTop", "False" )
	centerWindows(LoginTab.staticimage[1])
	guiMoveToBack( LoginTab.staticimage[1] )
	guiSetEnabled( LoginTab.staticimage[1],false )


	LoginTab.staticimage[2] = guiCreateStaticImage((rx/2) - 320, (ry/2) - 290, 600, 159, "images/disc.png", false)

	guiSetVisible(LoginTab.staticimage[2],false)
	guiSetVisible(LoginTab.staticimage[1],false)
	CSGLoginWindow = guiCreateStaticImage((rx/2) - 185, (ry/2) - 160, 335, 455, "images/background.png", false)
	--centerWindows(CSGLoginWindow)
	CSGLoginUsernameField = guiCreateEdit(85, 68, 165, 32, username, false, CSGLoginWindow)
	CSGLoginLabel1 = guiCreateLabel(85, 30, 165, 28, "Username", false, CSGLoginWindow)
	guiLabelSetColor(CSGLoginLabel1, 238, 154, 0)
	guiSetFont(CSGLoginLabel1, "default-bold-small")
	guiLabelSetHorizontalAlign(CSGLoginLabel1, "center", false)
	guiLabelSetVerticalAlign(CSGLoginLabel1, "center")
	CSGLoginPasswordField = guiCreateEdit(85, 143, 165, 30, password, false, CSGLoginWindow)
	guiEditSetMasked(CSGLoginPasswordField, true)
	CSGLoginLabel2 = guiCreateLabel(85, 105, 165, 28, "Password", false, CSGLoginWindow)
	guiLabelSetColor(CSGLoginLabel2, 238, 154, 0)
	guiSetFont(CSGLoginLabel2, "default-bold-small")
	guiLabelSetHorizontalAlign(CSGLoginLabel2, "center", false)
	guiLabelSetVerticalAlign(CSGLoginLabel2, "center")
	LoginTab.checkbox[1] = guiCreateCheckBox(114, 183, 116, 34, "Remember me ?", true, false, CSGLoginWindow)
	guiSetFont(LoginTab.checkbox[1], "default-bold-small")
	CSGLoginJoinButton = guiCreateButton(76, 276, 184, 40, "Join the game", false, CSGLoginWindow,"Login")
	guiSetProperty(CSGLoginJoinButton, "NormalTextColour", "FFAAAAAA")
	LoginTab.staticimage[4] = guiCreateButton(76, 326, 184, 40, "Register", false, CSGLoginWindow,"Register")
	guiSetProperty(LoginTab.staticimage[4], "NormalTextColour", "FFAAAAAA")
	--LoginTab.staticimage[6] = guiCreateButton(76, 376, 184, 40, "Request new password", false, CSGLoginWindow,"Request")
	--guiSetProperty(LoginTab.staticimage[6], "NormalTextColour", "FFAAAAAA")
	CSGLoginLabel3 = guiCreateLabel(30, 227, 278, 32, "Always read server rules before you play!", false, CSGLoginWindow)
	guiLabelSetColor(CSGLoginLabel3, 0, 255, 0)
	guiLabelSetHorizontalAlign(CSGLoginLabel3, "center", false)
	guiLabelSetVerticalAlign(CSGLoginLabel3, "center")
	guiSetFont(CSGLoginLabel3,"default-bold-small")



	--[[updatesTab.staticimage[1] = guiCreateStaticImage(145, 175, 505, 310, "images/background.png", false)

	--updatesTab.gridlist[1] = guiCreateGridList(60, 220, 250, 200, false, CSGLoginWindow)
	updatesTab.gridlist[1] = guiCreateGridList(450, 100, 200, 300, false, CSGLoginWindow)
	guiGridListAddColumn(updatesTab.gridlist[1], "Date", 0.3)
	guiGridListAddColumn(updatesTab.gridlist[1], "Update", 0.3)
	guiGridListAddColumn(updatesTab.gridlist[1], "Developer", 0.3)

	updatesTab.memo[1] = guiCreateLabel(150, 180, 250, 200, "Click on updates to view", false, CSGLoginWindow)
	guiLabelSetColor(updatesTab.memo[1], 19, 234, 35)
	guiLabelSetHorizontalAlign(updatesTab.memo[1], "center", false)
	guiLabelSetVerticalAlign(updatesTab.memo[1], "center")
	guiSetFont(updatesTab.memo[1],"default-bold-small")
	---updatesTab.staticimage[2] = guiCreateButton(298, 256, 140, 34, "Return to Login panel", false, CSGLoginWindow,"return")
	updatesTab.memo[1] = guiCreateMemo(360, 220, 250, 200, "Click on update to view", false, CSGLoginWindow)
	guiMemoSetReadOnly(updatesTab.memo[1], true)
	]]


	if ( username ~= "" ) and password ~= "" then guiCheckBoxSetSelected( LoginTab.checkbox[1], true ) end

	guiSetVisible (CSGLoginWindow, false)

	-- Register window

	CSGRegisterWindow = guiCreateStaticImage((rx/2) - 250, (ry/2) - 160, 480, 430, "images/background.png", false)
	CSGRegisterLabel1 = guiCreateLabel(25, 70, 105, 30, "Username:", false, CSGRegisterWindow)
	guiSetFont(CSGRegisterLabel1, "default-bold-small")
	guiLabelSetColor(CSGRegisterLabel1, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel1, "center", false)
	guiLabelSetVerticalAlign(CSGRegisterLabel1, "center")
	CSGRegisterUsernameField = guiCreateEdit(141, 70, 266, 30, "", false, CSGRegisterWindow)
	CSGRegisterLabel2 = guiCreateLabel(25, 114, 105, 30, "Password:", false, CSGRegisterWindow)
	guiSetFont(CSGRegisterLabel2, "default-bold-small")
	guiLabelSetColor(CSGRegisterLabel2, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel2, "center", false)
	guiLabelSetVerticalAlign(CSGRegisterLabel2, "center")
	CSGRegisterPasswordField = guiCreateEdit(140, 114, 267, 30, "", false, CSGRegisterWindow)
	guiEditSetMasked(CSGRegisterPasswordField, true)
	CSGRegisterLabel3 = guiCreateLabel(59, 292, 359, 17, "Dual accounting is not allowed. Always read the rules.", false, CSGRegisterWindow)
	guiSetFont(CSGRegisterLabel3, "default-bold-small")
	guiLabelSetColor(CSGRegisterLabel3, 34, 139, 34)
	guiLabelSetHorizontalAlign(CSGRegisterLabel3, "center", false)
	CSGRegisterLabel4 = guiCreateLabel(25, 154, 104, 27, "Password:", false, CSGRegisterWindow)
	guiSetFont(CSGRegisterLabel4, "default-bold-small")
	guiLabelSetColor(CSGRegisterLabel4, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel4, "center", false)
	guiLabelSetVerticalAlign(CSGRegisterLabel4, "center")
	CSGRegisterPassword2Field = guiCreateEdit(140, 154, 267, 31, "", false, CSGRegisterWindow)
	guiEditSetMasked(CSGRegisterPassword2Field, true)
	CSGRegisterLabel5 = guiCreateLabel(35, 195, 104, 30, "Email Address:", false, CSGRegisterWindow)
	guiSetFont(CSGRegisterLabel5, "default-bold-small")
	guiLabelSetColor(CSGRegisterLabel5, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel5, "center", false)
	guiLabelSetVerticalAlign(CSGRegisterLabel5, "center")
	CSGRegisterEmailField = guiCreateEdit(140, 195, 267, 30, "", false, CSGRegisterWindow)
	CSGRegisterLabel6 = guiCreateLabel(30, 242, 79, 24, "Gender:", false, CSGRegisterWindow)
	guiSetFont(CSGRegisterLabel6, "default-bold-small")
	guiLabelSetColor(CSGRegisterLabel6, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGRegisterLabel6, "center", false)
	guiLabelSetVerticalAlign(CSGRegisterLabel6, "center")
	CSGRegisterMaleGender = guiCreateRadioButton(150, 247, 45, 19, "Male", false, CSGRegisterWindow)
	CSGRegisterFemaleGender = guiCreateRadioButton(326, 247, 67, 19, "Female", false, CSGRegisterWindow)
	registerTab.staticimage[1] = guiCreateButton(281, 351, 157, 35, "Create Account", false, CSGRegisterWindow,"create")
	registerTab.staticimage[2] = guiCreateButton(39, 351, 184, 35, "Return to login panel", false, CSGRegisterWindow,"return")
	guiSetVisible(CSGRegisterWindow,false)


	-- Popup window after creating account
	CSGRegisterPopup = guiCreateWindow(495,184,253,157,"New Gaming Community",false)
	CSGRegisterPopupLabel1 = guiCreateLabel(8,27,238,17,"Warning:",false,CSGRegisterPopup)
	guiLabelSetColor(CSGRegisterPopupLabel1,34,139,34)
	guiLabelSetHorizontalAlign(CSGRegisterPopupLabel1,"center",false)
	guiSetFont(CSGRegisterPopupLabel1,"default-bold-small")
	CSGRegisterPopupLabel2 = guiCreateLabel(8,52,235,61,"Your account is created and ready to use!\nBefore playing read the rules.\n\nVisit also: http://ngcmta.com",false,CSGRegisterPopup)
	guiLabelSetHorizontalAlign(CSGRegisterPopupLabel2,"center",false)
	guiSetFont(CSGRegisterPopupLabel2,"default-bold-small")
	CSGRegisterPopupButton = guiCreateButton(25,121,208,23,"Return to the login screen",false,CSGRegisterPopup)
	centerWindows ( CSGRegisterPopup )
	guiWindowSetMovable (CSGRegisterPopup, true)
	guiWindowSetSizable (CSGRegisterPopup, false)
	guiSetVisible (CSGRegisterPopup, false)


-- Password request window

	CSGPasswordWindow = guiCreateStaticImage((rx/2) - 230, (ry/2) - 150, 450, 317, "images/background.png", false)
	CSGPasswordLabel1 = guiCreateLabel(18, 92, 107, 29, "Accountname:", false, CSGPasswordWindow)
	guiSetFont(CSGPasswordLabel1, "default-bold-small")
	guiLabelSetColor(CSGPasswordLabel1, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGPasswordLabel1, "center", false)
	guiLabelSetVerticalAlign(CSGPasswordLabel1, "center")
	CSGPasswordUsernameField = guiCreateEdit(135, 92, 272, 29, "", false, CSGPasswordWindow)
	CSGPasswordLabel2 = guiCreateLabel(43, 196, 359, 17, "A new password will be sent to your email!", false, CSGPasswordWindow)
	guiSetFont(CSGPasswordLabel2, "default-bold-small")
	guiLabelSetColor(CSGPasswordLabel2, 34, 139, 34)
	guiLabelSetHorizontalAlign(CSGPasswordLabel2, "center", false)
	CSGPasswordEmailField = guiCreateEdit(135, 135, 272, 29, "", false, CSGPasswordWindow)
	CSGPasswordLabel3 = guiCreateLabel(18, 135, 107, 28, "Email Adress:", false, CSGPasswordWindow)
	guiSetFont(CSGPasswordLabel3, "default-bold-small")
	guiLabelSetColor(CSGPasswordLabel3, 238, 154, 0)
	guiLabelSetHorizontalAlign(CSGPasswordLabel3, "center", false)
	guiLabelSetVerticalAlign(CSGPasswordLabel3, "center")
	requestTab.staticimage[1] = guiCreateButton(243, 256, 184, 36, "Request new password", false, CSGPasswordWindow,"requestpass")
	requestTab.staticimage[2] = guiCreateButton(29, 256, 184, 36, "Return to login panel", false, CSGPasswordWindow,"return")

	guiSetVisible(CSGPasswordWindow,false)
	--centerWindows ( CSGPasswordWindow )


	-- New password window
	CSGNewPasswordWindow = guiCreateWindow(547, 320, 474, 290, "New gaming Community", false)
	CSGNewPasswordLabel1 = guiCreateLabel(10, 30, 456, 92, "NGC improved the account system and security.\nThis means your account will not work untill you changed your password.\nYour password is now secured with one of the better hashing algorithms.\nThis means nobody can see or decrypt your password.\n\nAfter you completed the password change you are able to play again!", false, CSGNewPasswordWindow)
	guiLabelSetHorizontalAlign(CSGNewPasswordLabel1, "center", false)
	CSGNewPasswordLabel2 = guiCreateLabel(200, 138, 90, 16, "New password:", false, CSGNewPasswordWindow)
	guiSetFont(CSGNewPasswordLabel2, "default-bold-small")
	CSGNewPasswordEdit1 = guiCreateEdit(116, 158, 246, 26, "", false, CSGNewPasswordWindow)
	guiEditSetMasked ( CSGNewPasswordEdit1, true )
	CSGNewPasswordLabel3 = guiCreateLabel(179, 194, 133, 15, "Repeat new password:", false, CSGNewPasswordWindow)
	guiSetFont(CSGNewPasswordLabel3, "default-bold-small")
	CSGNewPasswordEdit2 = guiCreateEdit(116, 215, 246, 26, "", false, CSGNewPasswordWindow)
	guiEditSetMasked ( CSGNewPasswordEdit2, true )
	CSGNewPasswordButton = guiCreateButton(116, 256, 248, 24, "Update my password", false, CSGNewPasswordWindow)
	CSGNewPasswordLabel4 = guiCreateLabel(10, 117, 451, 15, "Choose 2 new safe passwords!", false, CSGNewPasswordWindow)
	guiLabelSetHorizontalAlign(CSGNewPasswordLabel4, "center", false)
	centerWindows ( CSGNewPasswordWindow )
	guiWindowSetMovable (CSGNewPasswordWindow, true)
	guiWindowSetSizable (CSGNewPasswordWindow, false)
	guiSetVisible (CSGNewPasswordWindow, false)



	--New instructions window
	instructionWindow = guiCreateWindow(547,320,571,371,"NGC ~ Resolution Change Tutorial",false)
		guiSetAlpha(instructionWindow,1)
		guiWindowSetMovable(instructionWindow,false)
		guiWindowSetSizable(instructionWindow,false)
	label1 = guiCreateLabel(88,133,382,24,"Sorry, but your resolution is below our minimum requirements!",false,instructionWindow)
		guiLabelSetColor(label1,255,0,0)
		guiLabelSetVerticalAlign(label1,"center")
		guiLabelSetHorizontalAlign(label1,"center",false)
		guiSetFont(label1,"default-bold-small")
	rX,rY = guiGetScreenSize() --define the player's screen size.
	label2 = guiCreateLabel(5,163,560,201,"At NGC, we require your resolution to be higher than 800 x 600. Yours is: "..rX.." x "..rY..".\nTo proceed to play at NGC, please follow these instructions to change your resolution\n\n\nStep 1: Press ESC and click \"Settings\" on MTA's main menu.\nStep 2: Click on the \"Video\" tab\nStep 3: Change your resolution to be anything above 800 x 600.\n\nOnce thats done, restart your MTA and rejoin to be able to get onto the server.\nThanks for reading, and sorry for this incident!\n\n\n~New Gaming Community~",false,instructionWindow)
		guiLabelSetHorizontalAlign(label2,"center",true)
	image = guiCreateStaticImage(207,20,142,116,"Files/disc-logo.png",false,instructionWindow)
	guiWindowSetMovable(instructionWindow,false)
	guiWindowSetSizable(instructionWindow,false)
	guiSetVisible(instructionWindow,false)
	centerWindows(instructionWindow)
	addEventHandler( "onClientGUIClick", CSGRegisterPopupButton, showLoginWindow, false )
	addEventHandler( "onClientGUIClick", CSGNewPasswordButton, updatePlayerPasswords, false )
end

function centerWindows ( theWindow )
	local screenW,screenH=guiGetScreenSize()
	local windowW,windowH=guiGetSize(theWindow,false)
	local x,y = (screenW-windowW)/2,(screenH-windowH)/2
	guiSetPosition(theWindow,x,y,false)
end


-- Enable cursor
addEvent ( "setCursorEnabled", true )
function enableCursor ( state )
	if ( state ) then
		showCursor( true )
	else
		showCursor( false )
	end
end
addEventHandler( "setCursorEnabled", root, enableCursor )


-- Clear all fields
function clearEditFields ()
	guiSetText( CSGPasswordUsernameField, "" )
	guiSetText( CSGPasswordEmailField, "" )
	guiSetText( CSGRegisterUsernameField, "" )
	guiSetText( CSGRegisterPasswordField, "" )
	guiSetText( CSGRegisterPassword2Field, "" )
	guiSetText( CSGRegisterEmailField, "" )
end

-- Set the login window visable
addEvent ( "setLoginWindowVisable", true )
function showLoginWindow ()
	guiSetVisible (CSGLoginWindow, true)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	--guiSetVisible (updatesTab.staticimage[1], false)
	clearEditFields ()
	guiSetVisible(LoginTab.staticimage[2],true)
	guiSetVisible(LoginTab.staticimage[1],true)
	enableCursor ( true )
end
addEventHandler( "setLoginWindowVisable", root, showLoginWindow )

-- Set the register window visable
addEvent ( "setRegisterWindowVisable", true )
function showRegisterWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, true)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	--guiSetVisible (updatesTab.staticimage[1], false)
	enableCursor ( true )
end
addEventHandler( "setRegisterWindowVisable", root, showRegisterWindow )

-- Set the password window visable
addEvent ( "setPasswordWindowVisable", true )
function showPasswordWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, true)
	guiSetVisible (CSGRegisterPopup, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	--guiSetVisible (updatesTab.staticimage[1], false)
	enableCursor ( true )
end
addEventHandler( "setPasswordWindowVisable", root, showPasswordWindow )

-- Set the poup window visable
addEvent ( "setPopupWindowVisable", true )
function showPopupWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, true)
	--guiSetVisible (updatesTab.staticimage[1], false)
	enableCursor ( true )
end
addEventHandler( "setPopupWindowVisable", root, showPopupWindow )

-- Hide all windows
addEvent ( "setAllWindowsHided", true )
function hideAllWindows ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	guiSetVisible(LoginTab.staticimage[2],false)
	guiSetVisible(LoginTab.staticimage[1],false)
	--guiSetVisible (updatesTab.staticimage[1], false)
	enableCursor ( false )
end
addEventHandler( "setAllWindowsHided", root, hideAllWindows )
--[[
addEvent ( "clientPlayerLogin", true )
function clientPlayerLogin()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	guiSetVisible(LoginTab.staticimage[2],false)
	guiSetVisible(LoginTab.staticimage[1],false)
	--guiSetVisible (updatesTab.staticimage[1], false)
	enableCursor ( false )
end
addEventHandler( "clientPlayerLogin", root, clientPlayerLogin )]]

-- updates window
addEvent ( "showUpdateWindow", true )
function showUpdateWindow ()
	guiSetVisible (CSGLoginWindow, false)
	guiSetVisible (CSGRegisterWindow, false)
	guiSetVisible (CSGPasswordWindow, false)
	guiSetVisible (CSGRegisterPopup, false)
	guiSetVisible (CSGNewPasswordWindow, false)
	---guiSetVisible (updatesTab.staticimage[1], true)
	enableCursor ( true )
end
addEventHandler( "showUpdateWindow", root, showUpdateWindow )

-- Set the change password window visable
addEvent ( "setNewPasswordWindowVisable", true )
function showNewPasswordWindow ()
	guiSetVisible( CSGLoginWindow, false )
	guiSetVisible( CSGRegisterWindow, false )
	guiSetVisible( CSGPasswordWindow, false )
	guiSetVisible( CSGRegisterPopup, false )
	guiSetVisible( CSGNewPasswordWindow, true )
	guiSetVisible(LoginTab.staticimage[2],false)
	guiSetVisible(LoginTab.staticimage[1],false)
	---guiSetVisible (updatesTab.staticimage[1], false)
	enableCursor ( true )
end
addEventHandler( "setNewPasswordWindowVisable", root, showNewPasswordWindow )

-- Create the GUI on connect or start
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()),
	function ()
		guiSetInputMode("no_binds_when_editing")
		--setCameraMatrix(1468.8785400391, -919.25317382813, 100.153465271, 1468.388671875, -918.42474365234, 99.881813049316)
		createAccountingWindows()
		screenX, screenY = guiGetScreenSize()
		if ( screenX >= 800 ) and ( screenY >= 600 ) then
			triggerServerEvent( "doSpawnPlayer", localPlayer )
		else
			openInstructionsWindow() --open instructions window.
		end
	end
)




function openInstructionsWindow()
	guiSetVisible(instructionWindow,true)
	showCursor(true)
end



--LOGIN
-- Get all the fields from the login screen
function getLoginWindowData ()
	return guiGetText ( CSGLoginUsernameField ), guiGetText ( CSGLoginPasswordField ), guiCheckBoxGetSelected ( LoginTab.checkbox[1] )
end

-- Get all the fields from register window
function getRegisterWindowData ()
	local username = guiGetText ( CSGRegisterUsernameField )
	local password1 = guiGetText ( CSGRegisterPasswordField )
	local password2 = guiGetText ( CSGRegisterPassword2Field )
	local email = guiGetText ( CSGRegisterEmailField )
	local genderMale = guiRadioButtonGetSelected( CSGRegisterMaleGender )
	local genderFemale = guiRadioButtonGetSelected( CSGRegisterFemaleGender )
	return username, password1, password2, email, genderMale, genderFemale
end


-- Get all the data from the password request screen
function getPasswordWindowData ()
	return guiGetText ( CSGPasswordUsernameField ), guiGetText ( CSGPasswordEmailField )
end

-- Get all data rom the new password window
function getNewPasswordWindowData ()
	return guiGetText ( CSGNewPasswordEdit1 ), guiGetText ( CSGNewPasswordEdit2 )
end

-- Function to update the password
function updatePlayerPasswords ()
	local password1, password2 = getNewPasswordWindowData ()
	if ( password1:match( "^%s*$" ) ) or ( password2:match( "^%s*$" ) ) then
		setWarningLabelText ( "The password field is empty!", "newPasswordWindow", 225, 0, 0 )
	elseif ( password1 ~= password2 ) then
		setWarningLabelText ( "The passwords don't match!", "newPasswordWindow", 225, 0, 0 )
	elseif ( string.len( password1 ) < 8 ) then
		setWarningLabelText ( "Your password is too short!", "newPasswordWindow", 225, 0, 0 )
	elseif ( md5( password1 ) == getElementData( source, "temp:UsernameData" ) ) then
		setWarningLabelText ( "You can't use the same password as your current!", "newPasswordWindow", 225, 0, 0 )
	else
		setWarningLabelText ( "Updating password...", "newPasswordWindow", 225, 80, 0 )
		triggerServerEvent( "onPlayerUpdatePasswords", localPlayer, password1 )
	end
end


function clickPanelButton (button, state)
    if button == "left" and state == "up" then
    local element = getElementData(getLocalPlayer(),"clickedButton")
        if element then
			if exports.server:isPlayerLoggedIn(localPlayer) then return false end
            local info = getElementData(element,"info")
			if info and info == "Login" then
				if not guiGetEnabled(element) then
					exports.NGCdxmsg:createNewDxMessage("Please wait few seconds, stop clicking!",255,0,0)
				return false end
				local myFPS = getElementData(localPlayer,"FPS")
				if tonumber(myFPS) <= 5 then
					exports.NGCdxmsg:createNewDxMessage("You can't enter the game while you are lagging.(FPS: "..myFPS..")",255,0,0)
					return false
				end
				local myPing = getPlayerPing(localPlayer)
				if tonumber(myPing) >= 2000 then
					exports.NGCdxmsg:createNewDxMessage("You can't enter the game while you are lagging.(PING: "..myPing..")",255,0,0)
					return false
				end
				if getElementData(localPlayer,"isThisMe") then
					exports.NGCdxmsg:createNewDxMessage("Please wait , Attempting to login!",255,0,0)
				return false end
				local username, password, usernameTick, passwordTick = getLoginWindowData()
				if ( username:match( "^%s*$" ) ) then
					setWarningLabelText ( "The accountname field is empty!", "loginWindow", 225, 0, 0 )
				elseif ( password:match( "^%s*$" ) ) then
					setWarningLabelText ( "The password field is empty!", "loginWindow", 225, 0, 0 )
				else
					local msgLabel = getElementData(element,"whereLabel")
					guiSetEnabled(element,false)
					setElementData(localPlayer,"isThisMe",true)
					outputDebugString("Attempting to login")
					--[[num = 5
					guiSetText(msgLabel,"Please wait ("..num.." sec's)...")
					setWarningLabelText ( "Attempting to login...", "loginWindow", 225, 165, 0 )

					setTimer(function(theLabel) num = 4 guiSetText(theLabel,"Please wait ("..num.." sec's)...") end,1000,1,msgLabel)
					setTimer(function(theLabel) num = 3 guiSetText(theLabel,"Please wait ("..num.." sec's)...") end,2000,1,msgLabel)
					setTimer(function(theLabel) num = 2 guiSetText(theLabel,"Please wait ("..num.." sec's)...") end,3000,1,msgLabel)
					setTimer(function(theLabel) num = 1 guiSetText(theLabel,"Please wait ("..num.." sec's)...") end,4000,1,msgLabel)
					]]
					triggerServerEvent( "doPlayerLogin", localPlayer, username, password, usernameTick, passwordTick )
					if isTimer(timer3) then return false end
					timer3 = setTimer(function(btn,lbl,usernamex, passwordx, usernameTickx, passwordTickx)
					--	guiSetText(lbl,"Join the Game")
						guiSetEnabled(btn,true)
					end,2000,1,element,msgLabel,username, password, usernameTick, passwordTick)
					if isTimer(timer4) then return false end
					timer4 = setTimer(function()
						setElementData(localPlayer,"isThisMe",false)
					end,5000,1)
				end
			elseif info and info == "Register" then
				showRegisterWindow()
			elseif info and info == "create" then
				local username, password1, password2, email, genderMale, genderFemale = getRegisterWindowData ()
				if ( username:match( "^%s*$" ) ) then
					setWarningLabelText ( "The accountname field is empty!", "registerWindow", 225, 0, 0 )
				elseif ( password1:match( "^%s*$" ) ) or ( password2:match( "^%s*$" ) ) then
					setWarningLabelText ( "The password field is empty!", "registerWindow", 225, 0, 0 )
				elseif ( password1 ~= password2 ) then
					setWarningLabelText ( "The passwords don't match!", "registerWindow", 225, 0, 0 )
				elseif ( string.len( password1 ) < 8 ) then
					setWarningLabelText ( "Your password is too short!", "registerWindow", 225, 0, 0 )
				elseif not ( genderMale ) and not ( genderFemale ) then
					setWarningLabelText ( "You didn't select a gender!", "registerWindow", 225, 0, 0 )
				elseif ( ( string.match( email, "^.+@.+%.%a%a%a*%.*%a*%a*%a*") ) ) then
					setWarningLabelText ( "Creating a new account...", "registerWindow", 225, 165, 0 )
					triggerServerEvent( "doAccountRegister", localPlayer, username, password1, password2, email, genderMale, genderFemale )
				else
					setWarningLabelText ( "You didn't enter a vaild email adress!", "registerWindow", 225, 0, 0 )
				end
			elseif info and info == "Request" then
				showPasswordWindow()
			elseif info and info == "requestpass" then
				local username, email = getPasswordWindowData ()
				if ( email:match("^%s*$") ) then
					setWarningLabelText ( "You didn't enter a email adress!", "passwordWindow", 225, 0, 0 )
				elseif ( username:match("^%s*$") ) then
					setWarningLabelText ( "You didn't enter a accountname!", "passwordWindow", 225, 0, 0 )
				elseif not ( string.match(email, "^.+@.+%.%a%a%a*%.*%a*%a*%a*") )then
					setWarningLabelText ( "You didn't enter a vaild email adress!", "passwordWindow", 225, 0, 0 )
				else
					triggerServerEvent( "doPlayerPasswordReset", localPlayer, email, username, exports.server:randomString( 10 ) )
				end
			elseif info and info == "Updates" then
				showUpdateWindow()
				triggerServerEvent("loadQueryUpdates",localPlayer)
			elseif info and info == "return" then
				showLoginWindow ()
			end
        end
	end
end
addEventHandler("onClientClick",getRootElement(),clickPanelButton)



-- Set the warning label data
addEvent ( "setWarningLabelText", true )
function setWarningLabelText ( theText, theType, r, g, b )
	if ( theType == "loginWindow" ) then
		guiSetText( CSGLoginLabel3, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGLoginLabel3, r, g, b ) end
	elseif ( theType == "registerWindow" ) then
		guiSetText( CSGRegisterLabel3, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGRegisterLabel3, r, g, b ) end
	elseif ( theType == "passwordWindow" ) then
		guiSetText( CSGPasswordLabel2, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGPasswordLabel2, r, g, b ) end
	elseif ( theType == "newPasswordWindow" ) then
		guiSetText( CSGNewPasswordLabel4, theText )
		if ( r ) and ( g ) and ( b ) then guiLabelSetColor( CSGNewPasswordLabel4, r, g, b ) end
	end
end
addEventHandler( "setWarningLabelText", root, setWarningLabelText )


--[[
addEventHandler ( 'onClientGUIClick', root, function ( btn )
	if ( source == updatesTab.gridlist[1] ) then
		local row, col = guiGridListGetSelectedItem ( updatesTab.gridlist[1] )
		if ( row ~= -1 and col ~= 0 ) then
			guiSetText ( updatesTab.memo[1], guiGridListGetItemText ( updatesTab.gridlist[1], row, 2 ) )
		else
			outputChatBox ( "Select an update.", 255, 255, 0 )
		end
	end
end)

addEvent ( "queryUpdatesLoaded", true )
addEventHandler ( "queryUpdatesLoaded", root, function ( window, ag1 )
	if ( window == 'main' ) then
		guiGridListClear ( updatesTab.gridlist[1] )
		if ( type ( ag1 ) == 'table' ) then
			currentList = { }
			-- Reverse the loop --
			local updates = { }
			for index, variable in ipairs ( ag1 ) do
				local lol = updates
				updates = { }
				table.insert ( updates, { variable['Date_'], variable['Name'], variable['Developer'] } )
				for i, v in ipairs ( lol ) do
					table.insert ( updates, v )
				end
			end
			for i,v in ipairs ( updates ) do
				local row = guiGridListAddRow ( updatesTab.gridlist[1] )
				guiGridListSetItemText ( updatesTab.gridlist[1], row, 1, tostring ( v[1] ), false, false )
				guiGridListSetItemText ( updatesTab.gridlist[1], row, 2, tostring (v[2] ), false, false )
				guiGridListSetItemText ( updatesTab.gridlist[1], row, 3, tostring (v[3] ), false, false )
			end
			currentList = updates
		else
			guiGridListSetItemText ( updatesTab.gridlist[1], guiGridListAddRow ( updatesTab.gridlist[1] ), 2, "Failed to load updates", true, true )
		end
	end
end)
]]

-- Some drawing things
local screenX, screenY = guiGetScreenSize()
local scaleMain = 2
local scaleGeneral = 1.5
local startX, startY = 80.0, 98.0
local sizeHeight = 150

if ( screenX == 1024 ) then
	scaleMain = 1.5
	scaleGeneral = 1
	sizeHeight = 125
elseif ( screenX == 800 ) then
	scaleMain = 1.5
	scaleGeneral = 1
	sizeHeight = 100
	startY = 98
elseif ( screenX == 600 ) then
	scaleMain = 1.1
	scaleGeneral = 0.8
	sizeHeight = 70
end


-- Convert a timeStamp to a date
function timestampConvert (timeStamp)
	local time = getRealTime(timeStamp)
	local year = time.year + 1900
	local month = time.month + 1
	local day = time.monthday
	local hour = time.hour
	local minute = time.minute

	return "" .. hour ..":" .. minute .." - " .. month .."/" .. day .."/" .. year ..""
end

-- Show the ban screen when trigger serverside
addEvent( "drawClientBanScreen", true )
addEventHandler( "drawClientBanScreen", root,
	function ( banSerial, banReason, banBantime, bannedby )
		TheBanSerial = banSerial
		TheBanReason = banReason
		TheBanBantime = timestampConvert( banBantime )
		TheBanBanner = bannedby
		addEventHandler("onClientRender", root, drawBanScreen )
		toggleAllControls(source,false,false,false,false)
	end
)

-- Draw the ban screen window
function drawBanScreen ()
	dxDrawText("This serial is banned from the server!",startX, startY,796.0,157,tocolor(200,0,0,230),scaleMain,"pricedown","left","top",false,false,false)
	dxDrawText("Reason: "..TheBanReason,startX,startY+(sizeHeight*1)+15,796.0,sizeHeight,tocolor(238,118,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	if(banBantime ~= 0) then
		dxDrawText("Banned till: "..TheBanBantime,startX,startY+(sizeHeight*2)+5,796.0,sizeHeight,tocolor(238,118,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	else
		dxDrawText("Permanently Banned",startX,startY+(sizeHeight*2)+5,796.0,sizeHeight,tocolor(238,118,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	end
	dxDrawText("Banned By: "..TheBanBanner ,startX,startY+(sizeHeight*3)+5,796.0,sizeHeight,tocolor(0,120,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
	dxDrawText("Serial: "..TheBanSerial,startX,startY+(sizeHeight*4)+5,796.0,sizeHeight,tocolor(0,120,0,230),scaleGeneral,"pricedown","left","top",false,false,false)
end

-- Some data for the scoreboard
setTimer (
	function ()
		setElementData ( localPlayer, "WL", getPlayerWantedLevel( localPlayer ) )
		setElementData ( localPlayer, "Money", "$ "..exports.server:convertNumber( getPlayerMoney( localPlayer ) ) )
		setElementData ( localPlayer, "City", exports.server:getPlayChatZone() )
	end, 1000, 0
)

-- Event when the client player logged in
addEvent( "clientPlayerLogin", true )
addEventHandler( "clientPlayerLogin", root,
	function ( userid, username )
		triggerEvent( "onSetPlayerSettings", root, source )
		triggerEvent( "onClientPlayerLogin", root, source, userid, username )
	end
)

-- Playtime of a user
setTimer (
	function ()
		if ( getElementData ( localPlayer, "playTime" ) ) then
			local theTime = ( getElementData ( localPlayer, "playTime" ) + 5 )
			setElementData( localPlayer, "playTime", math.floor( theTime ) )
			setElementData( localPlayer, "Play Time", math.floor( theTime / 60 ).." Hours" )
		else
			setElementData( localPlayer, "playTime", 0 )
			setElementData( localPlayer, "Play Time", 0 )
		end
	end, 60000*5, 0
)

-- When the player login set playtime
addEvent( "onClientPlayerLogin" )
addEventHandler( "onClientPlayerLogin", localPlayer,
	function ()
		if ( getElementData ( localPlayer, "playTime" ) ) then
			local theTime = ( getElementData ( localPlayer, "playTime" ) )
			setElementData( localPlayer, "Play Time", math.floor( theTime / 60 ).." Hours" )
		else
			setElementData( localPlayer, "playTime", 0 )
			setElementData( localPlayer, "Play Time", 0 )
		end
	end
)



function collectPing()
	local ping = setElementData(localPlayer,"Ping",getPlayerPing(localPlayer))
end
setTimer(collectPing,1000,0)
